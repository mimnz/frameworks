<?php

class Aluno
{
    private $id;
    private $nome;
    private $nascimento;
    private $curso;

    public function getId() { return $this->id; }
    public function setId($id) { $this->id = $id; }
    public function getNome() { return $this->nome; }
    public function setNome($nome) { $this->nome = $nome; }
    public function getNascimento() { return $this->nascimento; }
    public function setNascimento($nascimento) { $this->nascimento = $nascimento; }
    public function getCurso() { return $this->curso; }
    public function setCurso($curso) { $this->curso = $curso; }
}
?>