<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Framework MVC - Gerador de Models</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container" style="max-width: 500px;">
        <h2>Gerador de Modelos MVC</h2>
        <p class="subtitle">Insira seu arquivo .sql para mapear o banco e criar as classes</p>

        <?php
        if (isset($_GET['erro']) && $_GET['erro'] == '0') {
            echo "<span class='alerta alerta-erro'>Erro: Apenas arquivos com a extensão <b>.sql</b> são permitidos!</span>";
        } elseif (isset($_GET['sucesso'])) {
            echo "<span class='alerta alerta-sucesso'>Modelos gerados com sucesso na pasta!</span>";
        }
        ?>

        <form action="lerArquivo.php" method="post" enctype="multipart/form-data">
            <div class="upload-box">
                <label for="arquivo">Selecione o arquivo SQL</label>
                <input type="file" name="arquivo" id="arquivo" accept=".sql" required>
            </div>
            <button type="submit">Gerar Classes PHP</button>
        </form>
    </div>

</body>
</html>