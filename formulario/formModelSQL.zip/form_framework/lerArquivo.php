<?php
require_once 'LeitorSQL.php';

$arquivo = $_FILES['arquivo'];
$arquivo_tmp = $arquivo['tmp_name'];
$arquivo_size = $arquivo['size'];
$arquivo_name = explode('.', $arquivo['name']);
$extensao = strtolower(end($arquivo_name));
?>
<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Resultado do Processamento</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="wrapper-central">

    <div class="container">
        <h2>Resultado do Processamento SQL</h2>
    </div>

    <?php
    if ($extensao != "sql") {
        header("Location: formUpload.php?erro=0");
        exit();
    }

    $diretorioModel = 'model';

    if (!is_dir($diretorioModel)) {
        mkdir($diretorioModel, 0777, true);
    }

    if (move_uploaded_file($arquivo_tmp, $arquivo["name"])) {
        $nomeArquivoSalvo = $arquivo["name"];

        try {
            $leitor = new LeitorSQL($nomeArquivoSalvo);
            $tabelas = $leitor->getTabelas();

            echo "<div class='alerta alerta-sucesso'>✓ Arquivo '$nomeArquivoSalvo' mapeado com sucesso!</div>";

            foreach ($tabelas as $tabela) {
                $nomeClasse = ucfirst($tabela);
                $caminhoArquivoModel = $diretorioModel . '/' . $nomeClasse . '.php';
                
                // Montagem da estrutura do código PHP string
                $codigoPHP = "<?php\n\nclass " . $nomeClasse . "\n{\n";
                $atributos = $leitor->getAtributos($tabela);
                
                foreach ($atributos as $campo => $detalhes) {
                    $codigoPHP .= "    private \$$campo;\n";
                }
                $codigoPHP .= "\n";
                
                foreach ($atributos as $campo => $detalhes) {
                    $nomeMetodo = ucfirst($campo);
                    $codigoPHP .= "    public function get" . $nomeMetodo . "() { return \$this->" . $campo . "; }\n";
                    $codigoPHP .= "    public function set" . $nomeMetodo . "(\$" . $campo . ") { \$this->" . $campo . " = \$" . $campo . "; }\n";
                }
                $codigoPHP .= "}\n?>";
                
                if (file_put_contents($caminhoArquivoModel, $codigoPHP) !== false) {
                    ?>
                    <div class="card">
                        <h3>Tabela: <?= $tabela ?> <span>Classe <?= $nomeClasse ?> Gerada</span></h3>
                        <div class="path-info">Salvo em: <?= $caminhoArquivoModel ?></div>
                        
                        <ul>
                            <?php foreach ($atributos as $campo => $detalhes): ?>
                                <li>
                                    <div>
                                        <strong><?= $campo ?></strong>
                                        <?= $detalhes['primary'] ? "<span class='badge-pk'>PK</span>" : "" ?>
                                    </div>
                                    <span class="type-text"><?= $detalhes['tipo'] ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <?php
                }
            }

            echo "<a href='formUpload.php' class='btn-voltar'>← Criar novos Modelos</a>";

        } catch (Exception $e) {
            echo "<div class='alerta alerta-erro'>Erro ao processar: " . $e->getMessage() . "</div>";
            echo "<a href='formUpload.php' class='btn-voltar'>Voltar</a>";
        }

    } else {
        echo "<div class='alerta alerta-erro'>Erro crítico ao mover o arquivo para o servidor.</div>";
        echo "<a href='formUpload.php' class='btn-voltar'>Voltar</a>";
    }
    ?>

</div>
</body>
</html>