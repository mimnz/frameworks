<?php

require_once 'LeitorSQL.php';

$arquivo = $_FILES['arquivo'];
$arquivo_tmp = $arquivo['tmp_name'];
$arquivo_size = $arquivo['size'];
$arquivo_name = explode('.', $arquivo['name']);
$extensao = strtolower(end($arquivo_name));

echo "<h2>Resultado do Processamento SQL</h2>";

if ($extensao != "sql") {
    header("Location: formUpload.php?erro=0");
    exit();
}

if (move_uploaded_file($arquivo_tmp, $arquivo["name"])) {
    
    $nomeArquivoSalvo = $arquivo["name"];

    try {
        $leitor = new LeitorSQL($nomeArquivoSalvo);
        
        $tabelas = $leitor->getTabelas();

        echo "<p style='color: green;'><b>Arquivo '$nomeArquivoSalvo' enviado e lido com sucesso!</b></p>";
        echo "<hr>";

        foreach ($tabelas as $tabela) {
            echo "<h3>Tabela: <span style='color: blue;'>$tabela</span></h3>";
            
            $atributos = $leitor->getAtributos($tabela);
            
            echo "<ul>";
            foreach ($atributos as $campo => $detalhes) {
                $isPk = $detalhes['primary'] ? " <b>[Chave Primária]</b>" : "";
                echo "<li>Campo: <b>$campo</b> | Tipo: <i>" . $detalhes['tipo'] . "</i>$isPk</li>";
            }
            echo "</ul>";
            echo "<br>";
        }

        echo "<a href='formUpload.php'>← Enviar outro arquivo</a>";

    } catch (Exception $e) {
        echo "<p style='color: red;'>Erro ao ler a estrutura do SQL: " . $e->getMessage() . "</p>";
        echo "<a href='formUpload.php'>Voltar</a>";
    }

} else {
    echo "<p style='color: red;'>Erro ao mover o arquivo para o servidor.</p>";
    echo "<a href='formUpload.php'>Voltar</a>";
}
?>