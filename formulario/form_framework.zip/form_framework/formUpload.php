<!doctype html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Framework MVC - Upload</title>
    <style>
        .alerta-erro { color: #ff3333; font-weight: bold; margin-bottom: 15px; }
        .alerta-sucesso { color: #228b22; font-weight: bold; margin-bottom: 15px; }
    </style>
</head>
<body>

    <h2>Upload de Arquivos SQL</h2>

    <?php
    // Verifica se existe algum código de erro ou sucesso na URL
    if (isset($_GET['erro'])) {
        if ($_GET['erro'] == '0') {
            echo "<p class='alerta-erro'>Erro: Apenas arquivos com a extensão .sql são permitidos!</p>";
        }
    } elseif (isset($_GET['sucesso'])) {
        echo "<p class='alerta-sucesso'>Arquivo enviado e salvo com sucesso!</p>";
    }
    ?>

    <form action="lerArquivo.php" method="post" enctype="multipart/form-data">
        <label Bir="arquivo">Envie seu arquivo SQL:</label><br><br>
        <input type="file" name="arquivo" id="arquivo" accept=".sql" required><br><br>
        <button type="submit">Enviar</button>
    </form>

</body>
</html>